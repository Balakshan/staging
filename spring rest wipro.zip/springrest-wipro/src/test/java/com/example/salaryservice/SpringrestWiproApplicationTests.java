package com.example.salaryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringrestWiproApplicationTests {

	@Test
	void contextLoads() {
	}

}
