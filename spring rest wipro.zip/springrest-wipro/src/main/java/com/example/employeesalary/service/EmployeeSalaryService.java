package com.example.employeesalary.service;

import com.example.employeesalary.exception.EmployeeNotFoundException;
import com.example.employeesalary.exception.InvalidSalaryException;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class EmployeeSalaryService {

    private final Map<String, Double> employeeSalaryMap = new HashMap<>();

    public EmployeeSalaryService() {
        // Initializing with some employees
        employeeSalaryMap.put("Balakishan", 70000.00);
        employeeSalaryMap.put("RAJU", 85000.00);
        employeeSalaryMap.put("RANI", null); // Simulating a null salary
    }

    public Double getSalary(String employeeName) {
        if (!employeeSalaryMap.containsKey(employeeName)) {
            throw new EmployeeNotFoundException("Employee not found: " + employeeName);
        }
        Double salary = employeeSalaryMap.get(employeeName);
        if (salary == null) {
            throw new InvalidSalaryException("Salary not found for employee: " + employeeName);
        }
        return salary;
    }
}
