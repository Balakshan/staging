package com.example.employeesalary.controller;

import com.example.employeesalary.service.EmployeeSalaryService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EmployeeSalaryControllerTest {

    private final EmployeeSalaryService service = mock(EmployeeSalaryService.class);
    private final EmployeeSalaryController controller = new EmployeeSalaryController(service);

    @Test
    void testGetEmployeeSalary_Success() {
        when(service.getSalary("Alice")).thenReturn(70000.00);

        ResponseEntity<Double> response = controller.getEmployeeSalary("Alice");

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(70000.00, response.getBody());
    }

    @Test
    void testGetEmployeeSalary_NotFound() {
        when(service.getSalary("David")).thenThrow(new RuntimeException("Employee not found"));

        Exception exception = assertThrows(RuntimeException.class, () -> controller.getEmployeeSalary("David"));
        assertEquals("Employee not found", exception.getMessage());
    }
}
