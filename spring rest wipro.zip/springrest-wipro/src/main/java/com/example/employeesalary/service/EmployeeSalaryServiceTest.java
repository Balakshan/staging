package com.example.employeesalary.service;

import com.example.employeesalary.exception.EmployeeNotFoundException;
import com.example.employeesalary.exception.InvalidSalaryException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeSalaryServiceTest {

    private final EmployeeSalaryService service = new EmployeeSalaryService();

    @Test
    void testGetSalary_ValidEmployee() {
        Double salary = service.getSalary("Alice");
        assertNotNull(salary);
        assertEquals(70000.00, salary);
    }

    @Test
    void testGetSalary_EmployeeNotFound() {
        assertThrows(EmployeeNotFoundException.class, () -> service.getSalary("David"));
    }

    @Test
    void testGetSalary_NullSalary() {
        assertThrows(InvalidSalaryException.class, () -> service.getSalary("Charlie"));
    }
}
