package com.example.employeesalary.integration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class EmployeeSalaryIntegrationTest {

    private final TestRestTemplate restTemplate = new TestRestTemplate();

    @Test
    void testGetSalary_Success() {
        ResponseEntity<Double> response = restTemplate.getForEntity("http://localhost:8080/api/employees/salary/Alice", Double.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(70000.00, response.getBody());
    }

    @Test
    void testGetSalary_NotFound() {
        ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:8080/api/employees/salary/David", String.class);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void testGetSalary_NullSalary() {
        ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:8080/api/employees/salary/Charlie", String.class);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
}
