package com.example.employeesalary.controller;

import com.example.employeesalary.service.EmployeeSalaryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/employees")
public class EmployeeSalaryController {

    private final EmployeeSalaryService employeeSalaryService;

    public EmployeeSalaryController(EmployeeSalaryService employeeSalaryService) {
        this.employeeSalaryService = employeeSalaryService;
    }

    @GetMapping("/salary/{employeeName}")
    public ResponseEntity<Double> getEmployeeSalary(@PathVariable String employeeName) {
        Double salary = employeeSalaryService.getSalary(employeeName);
        return ResponseEntity.ok(salary);
    }
}
