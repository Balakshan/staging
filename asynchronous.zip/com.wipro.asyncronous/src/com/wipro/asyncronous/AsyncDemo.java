package com.wipro.asyncronous;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class AsyncDemo {
    public static void main(String[] args) {
        System.out.println("Main program started...");

        // Calling async method
        CompletableFuture<String> future = performAsyncTask();

    
        System.out.println("Main program is doing other work...");

        
        future.thenAccept(result -> System.out.println("Received result: " + result))
              .exceptionally(ex -> {
                  System.out.println("Error occurred: " + ex.getMessage());
                  return null;
              });

      
        try {
            Thread.sleep(5000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("Main program finished execution.");
    }

    public static CompletableFuture<String> performAsyncTask() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                System.out.println("Child thread started, simulating work...");
                TimeUnit.SECONDS.sleep(3); 
                return "Hello from Async Task!";
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        });
    }
}
